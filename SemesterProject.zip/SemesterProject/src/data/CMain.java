package data;

import forms.*;

public class CMain {

    public static void main(String[] args) 
    {
        CMainMenu oForm = new CMainMenu();
        oForm.setVisible(true);
    }
    
}

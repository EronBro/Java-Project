package forms;
import data.*;
import java.util.Timer;
import java.util.TimerTask;


public class CFormHelpCenter extends javax.swing.JFrame {

    CStringQueue calls;
    CStringQueue Employee1;
    CStringQueue Employee2;
    CStringQueue Employee3;
    CStringQueue Employee4;
    protected Timer timer;
    
    public CFormHelpCenter() {
        initComponents();
        this.calls = new CStringQueue(10);
        this.Employee1 = new CStringQueue(4);
        this.Employee2 = new CStringQueue(4);
        this.Employee3 = new CStringQueue(4);
        this.Employee4 = new CStringQueue(4);
        this.setTitle("Help Center");
        
        // Creates a periodic task object for a timer (example of anonymous class declaration)
        TimerTask oPeriodicTask = new TimerTask() 
           {
             @Override
             public void run() 
             {
                DistributeCalls();
             }
            };
         
        // Creates the timer
        this.timer = new Timer();
        // Adds a new periodic task object to the timer
        this.timer.scheduleAtFixedRate(oPeriodicTask, 0 , 10000);        
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnOpenLines = new javax.swing.JButton();
        lblCallWaitingQueue = new javax.swing.JLabel();
        lblBacklogQ1 = new javax.swing.JLabel();
        lblBacklogQ2 = new javax.swing.JLabel();
        lblBacklogQ3 = new javax.swing.JLabel();
        lblBacklogQ4 = new javax.swing.JLabel();
        btnAnswer2 = new javax.swing.JButton();
        btnAnswer1 = new javax.swing.JButton();
        btnAnswer3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtIncomingQ = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtBacklogQ1 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtBacklogQ2 = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtBacklogQ3 = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtBacklogQ4 = new javax.swing.JTextArea();
        btnAnswer4 = new javax.swing.JButton();
        txtName1 = new javax.swing.JTextField();
        lblProcessed1 = new javax.swing.JLabel();
        txtPhone1 = new javax.swing.JTextField();
        lblProcessed2 = new javax.swing.JLabel();
        txtPhone2 = new javax.swing.JTextField();
        txtName2 = new javax.swing.JTextField();
        lblProcessed3 = new javax.swing.JLabel();
        txtName3 = new javax.swing.JTextField();
        txtPhone3 = new javax.swing.JTextField();
        lblProcessed4 = new javax.swing.JLabel();
        txtPhone4 = new javax.swing.JTextField();
        txtName4 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnOpenLines.setText("OpenLines");
        btnOpenLines.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOpenLinesActionPerformed(evt);
            }
        });

        lblCallWaitingQueue.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblCallWaitingQueue.setText("Incoming Calls");

        lblBacklogQ1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblBacklogQ1.setText("Employee 1 Backlog");

        lblBacklogQ2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblBacklogQ2.setText("Employee 2 Backlog");

        lblBacklogQ3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblBacklogQ3.setText("Employee 3 Backlog");

        lblBacklogQ4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblBacklogQ4.setText("Employee 4 Backlog");

        btnAnswer2.setText("Answer2");
        btnAnswer2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnswer2ActionPerformed(evt);
            }
        });

        btnAnswer1.setText("Answer1");
        btnAnswer1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnswer1ActionPerformed(evt);
            }
        });

        btnAnswer3.setText("Answer3");
        btnAnswer3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnswer3ActionPerformed(evt);
            }
        });

        txtIncomingQ.setColumns(20);
        txtIncomingQ.setRows(5);
        jScrollPane1.setViewportView(txtIncomingQ);

        txtBacklogQ1.setColumns(20);
        txtBacklogQ1.setRows(5);
        jScrollPane2.setViewportView(txtBacklogQ1);

        txtBacklogQ2.setColumns(20);
        txtBacklogQ2.setRows(5);
        jScrollPane3.setViewportView(txtBacklogQ2);

        txtBacklogQ3.setColumns(20);
        txtBacklogQ3.setRows(5);
        jScrollPane4.setViewportView(txtBacklogQ3);

        txtBacklogQ4.setColumns(20);
        txtBacklogQ4.setRows(5);
        jScrollPane5.setViewportView(txtBacklogQ4);

        btnAnswer4.setText("Answer4");
        btnAnswer4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnswer4ActionPerformed(evt);
            }
        });

        lblProcessed1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblProcessed1.setText("Processed Call by 1");

        txtPhone1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPhone1ActionPerformed(evt);
            }
        });

        lblProcessed2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblProcessed2.setText("Processed Call by 2");

        lblProcessed3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblProcessed3.setText("Processed Call by 3");

        lblProcessed4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblProcessed4.setText("Processed Call by 4");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(btnAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(69, 69, 69)
                        .addComponent(btnAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(70, 70, 70)
                        .addComponent(btnAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(69, 69, 69)
                        .addComponent(btnAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPhone1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblProcessed1)
                            .addComponent(txtName1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(53, 53, 53)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblProcessed2)
                            .addComponent(txtPhone2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtName2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(52, 52, 52)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblProcessed3)
                            .addComponent(txtName3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPhone3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(51, 51, 51)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblProcessed4)
                            .addComponent(txtPhone4, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtName4, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(lblBacklogQ1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnOpenLines, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(lblBacklogQ2)
                                .addGap(14, 14, 14)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addComponent(lblBacklogQ3)
                                .addGap(50, 50, 50)
                                .addComponent(lblBacklogQ4))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(lblCallWaitingQueue))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(btnOpenLines, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(lblCallWaitingQueue)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblBacklogQ3)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblBacklogQ1)
                                .addComponent(lblBacklogQ4)
                                .addComponent(lblBacklogQ2)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addComponent(lblProcessed1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtPhone1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblProcessed3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtPhone3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtName3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblProcessed2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtPhone2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtName2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblProcessed4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtPhone4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtName4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DistributeCalls()
    {
        if (!calls.isEmpty())
            Employee1.Enqueue(calls.Dequeue());
        if (!calls.isEmpty())            
            Employee2.Enqueue(calls.Dequeue());
        if (!calls.isEmpty())
            Employee3.Enqueue(calls.Dequeue());
        if (!calls.isEmpty())
            Employee4.Enqueue(calls.Dequeue());
        
        PrintUpdate();    
    }
    
    public void PrintUpdate()
    {
        txtBacklogQ1.setText(Employee1.callsToString());
        txtBacklogQ2.setText(Employee2.callsToString());
        txtBacklogQ3.setText(Employee3.callsToString());
        txtBacklogQ4.setText(Employee4.callsToString());
        txtIncomingQ.setText(calls.callsToString());
    }
    private void btnOpenLinesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOpenLinesActionPerformed
        
        calls.Enqueue("Mr.Kaplanoglou:+306962387462");
        calls.Enqueue("Jurgen:+496980088899");
        calls.Enqueue("Jon:+355632764912");
        calls.Enqueue("Giorgos:+386923798734");
        calls.Enqueue("William:+306926347147");
        calls.Enqueue("Bori:+492827979234");
        calls.Enqueue("Lipe:+355762349122");
        calls.Enqueue("Tani:+387126481218");
        calls.Enqueue("Darien:+307836129191");
        calls.Enqueue("Anduel:+491892871238");
        
        PrintUpdate();

    }//GEN-LAST:event_btnOpenLinesActionPerformed

    private void btnAnswer1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnswer1ActionPerformed
        

        String[] parts1 = this.Employee1.callsToString().split(":");
        System.out.println("----------------");
        String Employee1Name = parts1[2];
        String Employee1Phone = parts1[1];
        System.out.println("----------------");
        this.txtName1.setText(Employee1Name);
        this.txtPhone1.setText(Employee1Phone);
        System.out.println(parts1[1]);
        System.out.println(parts1[2]);
        this.Employee1.Dequeue();
    }//GEN-LAST:event_btnAnswer1ActionPerformed

    private void txtPhone1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPhone1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhone1ActionPerformed

    private void btnAnswer2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnswer2ActionPerformed

        String[] parts2 = this.Employee2.callsToString().split(":");
        System.out.println("----------------");
        String Employee2Name = parts2[2];
        String Employee2Phone = parts2[1];
        System.out.println("----------------");
        this.txtName2.setText(Employee2Name);
        this.txtPhone2.setText(Employee2Phone);
        System.out.println(parts2[1]);
        System.out.println(parts2[2]);
        this.Employee2.Dequeue();
        
    }//GEN-LAST:event_btnAnswer2ActionPerformed

    private void btnAnswer3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnswer3ActionPerformed

        String[] parts3 = this.Employee3.callsToString().split(":");
        System.out.println("----------------");
        String Employee3Name = parts3[2];
        String Employee3Phone = parts3[1];
        System.out.println("----------------");
        this.txtName3.setText(Employee3Name);
        this.txtPhone3.setText(Employee3Phone);
        System.out.println(parts3[1]);
        System.out.println(parts3[2]);
        this.Employee3.Dequeue();
    }//GEN-LAST:event_btnAnswer3ActionPerformed

    private void btnAnswer4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnswer4ActionPerformed
 
        String[] parts4 = this.Employee4.callsToString().split(":");
        System.out.println("----------------");
        String Employee4Name = parts4[2];
        String Employee4Phone = parts4[1];
        System.out.println("----------------");
        this.txtName4.setText(Employee4Name);
        this.txtPhone4.setText(Employee4Phone);
        System.out.println(parts4[1]);
        System.out.println(parts4[2]);
        this.Employee4.Dequeue();
    }//GEN-LAST:event_btnAnswer4ActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CFormHelpCenter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CFormHelpCenter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CFormHelpCenter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CFormHelpCenter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CFormHelpCenter().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnswer1;
    private javax.swing.JButton btnAnswer2;
    private javax.swing.JButton btnAnswer3;
    private javax.swing.JButton btnAnswer4;
    private javax.swing.JButton btnOpenLines;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JLabel lblBacklogQ1;
    private javax.swing.JLabel lblBacklogQ2;
    private javax.swing.JLabel lblBacklogQ3;
    private javax.swing.JLabel lblBacklogQ4;
    private javax.swing.JLabel lblCallWaitingQueue;
    private javax.swing.JLabel lblProcessed1;
    private javax.swing.JLabel lblProcessed2;
    private javax.swing.JLabel lblProcessed3;
    private javax.swing.JLabel lblProcessed4;
    private javax.swing.JTextArea txtBacklogQ1;
    private javax.swing.JTextArea txtBacklogQ2;
    private javax.swing.JTextArea txtBacklogQ3;
    private javax.swing.JTextArea txtBacklogQ4;
    private javax.swing.JTextArea txtIncomingQ;
    private javax.swing.JTextField txtName1;
    private javax.swing.JTextField txtName2;
    private javax.swing.JTextField txtName3;
    private javax.swing.JTextField txtName4;
    private javax.swing.JTextField txtPhone1;
    private javax.swing.JTextField txtPhone2;
    private javax.swing.JTextField txtPhone3;
    private javax.swing.JTextField txtPhone4;
    // End of variables declaration//GEN-END:variables
}
